setup_windows Module
====================

.. automodule:: setup_windows
    :members:
    :undoc-members:
    :show-inheritance:
