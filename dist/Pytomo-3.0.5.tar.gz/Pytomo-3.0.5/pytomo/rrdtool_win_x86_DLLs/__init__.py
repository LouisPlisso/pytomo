#!/usr/bin/env python
''' The libraries in this package are necessary to build a Windows executable
for the Pytomo graphical web interface.

They have been obtained by compiling the RRDtool 1.4.7 Visual Studio project
on a Windows XP x86 machine and creating the Python binding:
    http://oss.oetiker.ch/rrdtool/pub/rrdtool-1.4.7.tar.gz
'''

from __future__ import absolute_import
